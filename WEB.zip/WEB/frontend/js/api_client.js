function api_client(url, content, callback){

    console.log(url)
    fetch(url, content)
    .then((response)=>{
        response.json().then(object =>{
            console.log(JSON.stringify(object))
            callback(object)
        })
    })
    .catch((error)=>{
        error.json().then(err =>{
            console.log("error")
            console.log(JSON.stringify(err))
            callback(err)
        })
    })
}