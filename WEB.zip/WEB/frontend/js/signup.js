

function signup(){
    let first_name = document.getElementById("firstname").value
    let last_name = document.getElementById("lastname").value
    let username = document.getElementById("username").value
    let password = document.getElementById("password").value

    console.log(`First Name = ${first_name}`)
    console.log(`Last Name = ${last_name}`)
    console.log(`UserName = ${username}`)
    console.log(`password = ${password}`)

    if (first_name == "" || last_name == "" || username == "" || password == ""){

        alert("Please enter required fields.")
    }
    else {
        let payload = {
            first_name: first_name,
            last_name: last_name,
            username: username,
            password: password
        }

        signupRequest(payload)

    }
}
function signupRequest(payload){

    console.log(JSON.stringify(payload))
     let url = "http://localhost:8000/users/register"

     let content = {
        method: 'POST',
        headers: {
            'Content-Type':'application/json'
        },
        body: JSON.stringify(payload)
     }

     api_client(url, content, (response)=>{

        console.log(JSON.stringify(response))
        if (response.successful == true){
            alert(response.message)
        }
        else{
            alert(response.message)
        }
     })

    }


